from math import sin, cos, tan, asin, acos, atan;

class seno(n):
    print("Seno de {} es: ".format(n), sin(n))
class coseno(n):
    print("Coseno de {} es: ".format(n), cos(n))
class tangente(n):
    print("Tangente de {} es: ".format(n), tan(n))
class aseno(n):
    print("Arcoseno de {} es: ".format(n), asin(n))
class acoseno(n):
    print("Arcocoseno de {} es: ".format(n), acos(n))
class atangente(n):
    print("Arcongente de {} es: ".format(n), atan(n))
