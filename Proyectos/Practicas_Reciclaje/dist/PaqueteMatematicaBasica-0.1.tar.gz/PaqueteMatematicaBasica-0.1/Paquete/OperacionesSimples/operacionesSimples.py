def sumar(n1,n2):
    print("El resultado de la suma es:", n1+n2)
def restar(n1,n2):
    print("El resultado de la resta es:", n1-n2)
def multiplicar(n1,n2):
    print("El resultado de la multiplicacion es:", n1*n2)
def dividir(n1,n2):
    print("El resultado de la division es:", n1/n2)
